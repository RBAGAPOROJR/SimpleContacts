//
//  AssignmentTwoApp.swift
//  AssignmentTwo
//
//  Created by RNLD on 2024-04-04.
//

import SwiftUI

@main
struct AssignmentTwoApp: App {
    
    var body: some Scene {
    
        WindowGroup {
            
            ContentView()
            
        }
    }
}
